# VentaPro Fullstack Real

Este ZIP ya deja el frontend conectado al backend Node/Express y la base SQLite.

## Ejecutar backend
```bash
cd backend
npm install
copy .env.example .env
npm run dev
```
La API queda en: http://localhost:8000

## Ejecutar frontend
En otra terminal:
```bash
cd frontend
npm install
npm run dev
```
El sistema queda en: http://localhost:5173

## Usuarios iniciales
- admin / admin1234
- cajero / cajero1234
- bodega / bodega1234
- supervisor / super1234

## Qué ya se conecta al backend
- Login real con JWT
- Productos desde SQLite
- Clientes desde SQLite
- Apertura y cierre de caja
- Ventas reales con descuento de stock
- Historial de ventas
- Compras e inventario
- Usuarios y configuración de empresa
- Auditoría y reportes básicos

Nota: la factura PDF sigue siendo demostrativa, no es comprobante autorizado SRI.
