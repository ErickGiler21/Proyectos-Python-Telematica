# VentaPro Minimarket - Versión final por roles

Sistema demo empresarial en React + Vite con datos en localStorage.

## Ejecutar

```bash
npm install
npm run dev
```

## Accesos

- Admin: `admin` / `admin1234`
- Cajero: `cajero` / `cajero1234`
- Bodega: `bodega` / `bodega1234`
- Supervisor: `supervisor` / `super1234`

## Funciones por rol

### Admin
- Crear usuarios.
- Activar/desactivar usuarios.
- Cambiar rol.
- Ver auditoría completa.
- Configurar empresa.
- Ver productos, inventario, compras, clientes, reportes y autorizaciones.

### Cajero
- Abrir caja.
- Vender.
- Reimprimir factura.
- Cerrar caja.
- Ver solo sus ventas.
- Descuentos requieren clave de supervisor.

### Bodega
- Agregar productos.
- Registrar compras.
- Entrada/salida/ajuste/devolución/merma/producto vencido.
- Ver stock bajo desde inventario/productos.
- No tiene menú de dinero ni reportes financieros.

### Supervisor
- Ver ventas de todos los cajeros.
- Autorizar/revisar descuentos.
- Autorizar devoluciones y notas de crédito.
- Revisar cierres de caja.
- Ver reportes básicos.

> Nota: esta versión es frontend/demo. Para negocio real se recomienda backend con Laravel/Node y PostgreSQL, login seguro y facturación electrónica SRI real.
