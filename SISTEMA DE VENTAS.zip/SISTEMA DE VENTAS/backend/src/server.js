import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { db, initDb, audit, invoiceNumber } from './db.js';

initDb();
const app = express();
const PORT = process.env.PORT || 8000;
const JWT_SECRET = process.env.JWT_SECRET || 'ventapro_cambiar_esta_clave_en_produccion';

app.use(cors({ origin: ['http://localhost:5173', 'http://127.0.0.1:5173'], credentials: true }));
app.use(express.json({ limit: '5mb' }));
app.use(morgan('dev'));

function sign(user) {
  return jwt.sign({ id: user.id, username: user.username, role: user.role, name: user.name }, JWT_SECRET, { expiresIn: '8h' });
}
function auth(req, res, next) {
  const token = (req.headers.authorization || '').replace('Bearer ', '');
  if (!token) return res.status(401).json({ message: 'Token requerido' });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ message: 'Token inválido o vencido' });
  }
}
function allow(...roles) {
  return (req, res, next) => roles.includes(req.user.role) ? next() : res.status(403).json({ message: 'No tienes permiso para esta acción' });
}
function getOpenSession(userId) {
  return db.prepare("SELECT * FROM cash_sessions WHERE user_id=? AND status='abierta' ORDER BY id DESC LIMIT 1").get(userId);
}

app.get('/api/health', (_, res) => res.json({ ok: true, app: 'VentaPro API', time: new Date().toISOString() }));

app.post('/api/auth/login', (req, res) => {
  const { username, password, role } = req.body;
  const user = db.prepare('SELECT * FROM users WHERE username=? AND active=1').get(username);
  if (!user || !bcrypt.compareSync(password || '', user.password_hash)) return res.status(401).json({ message: 'Usuario o contraseña incorrectos' });
  if (role && user.role !== role) return res.status(403).json({ message: 'Este usuario no pertenece a este acceso' });
  audit(user, 'LOGIN', `Ingreso al sistema como ${user.role}`);
  res.json({ token: sign(user), user: { id: user.id, name: user.name, username: user.username, role: user.role, active: !!user.active } });
});



function productRow(p){ return p; }
function companyRow(){ return db.prepare('SELECT * FROM company WHERE id=1').get(); }
function bootstrapData(req){
  const data = {
    company: companyRow(),
    products: db.prepare('SELECT * FROM products WHERE active=1 ORDER BY name LIMIT 1250').all(),
    clients: db.prepare('SELECT * FROM clients ORDER BY id DESC LIMIT 300').all(),
    sales: [],
    cashSessions: [],
    cashClosings: [],
    inventoryMoves: [],
    purchases: [],
    users: [],
    audit: [],
    pendingSales: [],
    notes: []
  };
  if (['admin','supervisor','cajero'].includes(req.user.role)) {
    const onlyMine = req.user.role === 'cajero';
    const sql = `SELECT s.*,u.name cashier,c.name client_name,c.doc client_doc,c.address client_address FROM sales s JOIN users u ON u.id=s.user_id JOIN clients c ON c.id=s.client_id ${onlyMine ? 'WHERE s.user_id=?' : ''} ORDER BY s.id DESC LIMIT 300`;
    const sales = onlyMine ? db.prepare(sql).all(req.user.id) : db.prepare(sql).all();
    data.sales = sales.map(sale => ({ ...sale, items: db.prepare('SELECT * FROM sale_items WHERE sale_id=?').all(sale.id) }));
  }
  if (req.user.role === 'cajero') {
    const open = getOpenSession(req.user.id);
    data.cashSessions = open ? [open] : [];
    data.cashClosings = db.prepare('SELECT * FROM cash_sessions WHERE user_id=? AND status=\'cerrada\' ORDER BY id DESC LIMIT 100').all(req.user.id);
  }
  if (['admin','supervisor'].includes(req.user.role)) {
    data.cashSessions = db.prepare('SELECT cs.*,u.name cashier FROM cash_sessions cs JOIN users u ON u.id=cs.user_id ORDER BY cs.id DESC LIMIT 200').all();
    data.cashClosings = data.cashSessions.filter(x => x.status === 'cerrada');
  }
  if (['admin','bodeguero','supervisor'].includes(req.user.role)) {
    data.inventoryMoves = db.prepare(`SELECT im.*,p.code,p.name product,u.name user FROM inventory_moves im JOIN products p ON p.id=im.product_id JOIN users u ON u.id=im.user_id ORDER BY im.id DESC LIMIT 300`).all();
  }
  if (['admin','bodeguero'].includes(req.user.role)) {
    data.purchases = db.prepare(`SELECT p.*,u.name user FROM purchases p JOIN users u ON u.id=p.user_id ORDER BY p.id DESC LIMIT 200`).all();
  }
  if (req.user.role === 'admin') {
    data.users = db.prepare('SELECT id,name,username,role,active,created_at,updated_at FROM users ORDER BY id DESC').all();
  }
  if (['admin','supervisor','bodeguero'].includes(req.user.role)) {
    data.audit = db.prepare('SELECT * FROM audit_log ORDER BY id DESC LIMIT 500').all();
  }
  return data;
}
app.get('/api/bootstrap', auth, (req, res) => res.json(bootstrapData(req)));

app.get('/api/company', auth, (req, res) => res.json(db.prepare('SELECT * FROM company WHERE id=1').get()));
app.put('/api/company', auth, allow('admin'), (req, res) => {
  const c = req.body;
  db.prepare(`UPDATE company SET ruc=?, name=?, trade_name=?, address=?, phone=?, email=?, iva=?, logo=?, updated_at=CURRENT_TIMESTAMP WHERE id=1`)
    .run(c.ruc, c.name, c.trade_name || c.tradeName, c.address, c.phone, c.email, Number(c.iva || 0.15), c.logo || '');
  audit(req.user, 'CONFIGURACION_EMPRESA', 'Actualizó datos de empresa');
  res.json(db.prepare('SELECT * FROM company WHERE id=1').get());
});

app.get('/api/users', auth, allow('admin'), (_, res) => res.json(db.prepare('SELECT id,name,username,role,active,created_at,updated_at FROM users ORDER BY id DESC').all()));
app.post('/api/users', auth, allow('admin'), (req, res) => {
  const { name, username, password, role } = req.body;
  if (!name || !username || !password || !role) return res.status(400).json({ message: 'Datos incompletos' });
  const info = db.prepare('INSERT INTO users (name,username,password_hash,role,active) VALUES (?,?,?,?,1)').run(name, username, bcrypt.hashSync(password, 10), role);
  audit(req.user, 'CREAR_USUARIO', `Creó usuario ${username} con rol ${role}`);
  res.status(201).json(db.prepare('SELECT id,name,username,role,active FROM users WHERE id=?').get(info.lastInsertRowid));
});
app.put('/api/users/:id', auth, allow('admin'), (req, res) => {
  const { name, role, active, password } = req.body;
  const user = db.prepare('SELECT * FROM users WHERE id=?').get(req.params.id);
  if (!user) return res.status(404).json({ message: 'Usuario no encontrado' });
  if (password) db.prepare('UPDATE users SET name=?, role=?, active=?, password_hash=?, updated_at=CURRENT_TIMESTAMP WHERE id=?').run(name, role, active ? 1 : 0, bcrypt.hashSync(password, 10), req.params.id);
  else db.prepare('UPDATE users SET name=?, role=?, active=?, updated_at=CURRENT_TIMESTAMP WHERE id=?').run(name, role, active ? 1 : 0, req.params.id);
  audit(req.user, 'EDITAR_USUARIO', `Editó usuario ID ${req.params.id}`);
  res.json(db.prepare('SELECT id,name,username,role,active FROM users WHERE id=?').get(req.params.id));
});

app.get('/api/products', auth, (req, res) => {
  const q = `%${(req.query.q || '').toLowerCase()}%`;
  const onlyLow = req.query.low === '1';
  let sql = `SELECT * FROM products WHERE active=1 AND (lower(code) LIKE ? OR lower(barcode) LIKE ? OR lower(name) LIKE ? OR lower(brand) LIKE ? OR lower(category) LIKE ?)`;
  if (onlyLow) sql += ' AND stock <= min_stock';
  sql += ' ORDER BY name LIMIT 250';
  res.json(db.prepare(sql).all(q, q, q, q, q));
});
app.post('/api/products', auth, allow('admin','bodeguero'), (req, res) => {
  const p = req.body;
  const info = db.prepare(`INSERT INTO products (code,barcode,name,brand,category,cost,price,iva,stock,min_stock,active) VALUES (?,?,?,?,?,?,?,?,?,?,1)`)
    .run(p.code, p.barcode || null, p.name, p.brand || '', p.category || '', Number(p.cost || 0), Number(p.price || 0), Number(p.iva || 0.15), Number(p.stock || 0), Number(p.min_stock || p.minStock || 5));
  audit(req.user, 'CREAR_PRODUCTO', `Creó ${p.code} - ${p.name}`);
  res.status(201).json(db.prepare('SELECT * FROM products WHERE id=?').get(info.lastInsertRowid));
});
app.put('/api/products/:id', auth, allow('admin','bodeguero'), (req, res) => {
  const p = req.body;
  db.prepare(`UPDATE products SET code=?, barcode=?, name=?, brand=?, category=?, cost=?, price=?, iva=?, stock=?, min_stock=?, active=?, updated_at=CURRENT_TIMESTAMP WHERE id=?`)
    .run(p.code, p.barcode || null, p.name, p.brand || '', p.category || '', Number(p.cost || 0), Number(p.price || 0), Number(p.iva || 0.15), Number(p.stock || 0), Number(p.min_stock || p.minStock || 5), p.active ? 1 : 0, req.params.id);
  audit(req.user, 'EDITAR_PRODUCTO', `Editó producto ID ${req.params.id}`);
  res.json(db.prepare('SELECT * FROM products WHERE id=?').get(req.params.id));
});
app.delete('/api/products/:id', auth, allow('admin'), (req, res) => {
  db.prepare('UPDATE products SET active=0, updated_at=CURRENT_TIMESTAMP WHERE id=?').run(req.params.id);
  audit(req.user, 'DESACTIVAR_PRODUCTO', `Desactivó producto ID ${req.params.id}`);
  res.json({ ok: true });
});

app.get('/api/clients', auth, (req, res) => {
  const q = `%${(req.query.q || '').toLowerCase()}%`;
  res.json(db.prepare('SELECT * FROM clients WHERE lower(doc) LIKE ? OR lower(name) LIKE ? ORDER BY name LIMIT 100').all(q, q));
});
app.post('/api/clients', auth, allow('admin','cajero','supervisor'), (req, res) => {
  const c = req.body;
  const info = db.prepare('INSERT INTO clients (doc,type,name,phone,email,address) VALUES (?,?,?,?,?,?)')
    .run(c.doc, c.type || 'Cliente', c.name, c.phone || '', c.email || '', c.address || '');
  audit(req.user, 'CREAR_CLIENTE', `Creó cliente ${c.doc} - ${c.name}`);
  res.status(201).json(db.prepare('SELECT * FROM clients WHERE id=?').get(info.lastInsertRowid));
});

app.post('/api/cash/open', auth, allow('cajero'), (req, res) => {
  const open = getOpenSession(req.user.id);
  if (open) return res.status(400).json({ message: 'Ya tienes una caja abierta', session: open });
  const info = db.prepare('INSERT INTO cash_sessions (user_id,opening_amount,status) VALUES (?,? ,\'abierta\')').run(req.user.id, Number(req.body.opening_amount || 0));
  audit(req.user, 'ABRIR_CAJA', `Monto inicial $${Number(req.body.opening_amount || 0).toFixed(2)}`);
  res.status(201).json(db.prepare('SELECT * FROM cash_sessions WHERE id=?').get(info.lastInsertRowid));
});
app.get('/api/cash/current', auth, allow('cajero'), (req, res) => res.json(getOpenSession(req.user.id) || null));
app.post('/api/cash/close', auth, allow('cajero'), (req, res) => {
  const session = getOpenSession(req.user.id);
  if (!session) return res.status(400).json({ message: 'No tienes caja abierta' });
  const sales = db.prepare("SELECT COALESCE(SUM(total),0) total FROM sales WHERE cash_session_id=? AND status='emitida'").get(session.id).total;
  const expected = Number(session.opening_amount) + Number(sales);
  const closing = Number(req.body.closing_amount || 0);
  const diff = closing - expected;
  db.prepare("UPDATE cash_sessions SET closing_amount=?, expected_amount=?, difference=?, status='cerrada', closed_at=CURRENT_TIMESTAMP WHERE id=?").run(closing, expected, diff, session.id);
  audit(req.user, 'CERRAR_CAJA', `Esperado ${expected.toFixed(2)}, contado ${closing.toFixed(2)}, diferencia ${diff.toFixed(2)}`);
  res.json(db.prepare('SELECT * FROM cash_sessions WHERE id=?').get(session.id));
});
app.get('/api/cash/sessions', auth, allow('admin','supervisor'), (req, res) => res.json(db.prepare(`SELECT cs.*,u.name cashier FROM cash_sessions cs JOIN users u ON u.id=cs.user_id ORDER BY cs.id DESC LIMIT 200`).all()));

app.post('/api/sales', auth, allow('cajero'), (req, res) => {
  const body = req.body;
  const session = getOpenSession(req.user.id);
  if (!session) return res.status(400).json({ message: 'Primero debes abrir caja' });
  if (!Array.isArray(body.items) || !body.items.length) return res.status(400).json({ message: 'La venta no tiene productos' });

  const tx = db.transaction(() => {
    const client = db.prepare('SELECT * FROM clients WHERE id=?').get(body.client_id || 1) || db.prepare('SELECT * FROM clients WHERE doc=?').get('9999999999999');
    let subtotal = 0, ivaTotal = 0;
    const prepared = body.items.map(item => {
      const product = db.prepare('SELECT * FROM products WHERE id=? AND active=1').get(item.product_id);
      if (!product) throw new Error('Producto no encontrado');
      const qty = Number(item.qty || 1);
      if (product.stock < qty) throw new Error(`Stock insuficiente para ${product.name}`);
      const ivaLine = product.price * product.iva * qty;
      const totalLine = (product.price + product.price * product.iva) * qty;
      subtotal += product.price * qty;
      ivaTotal += ivaLine;
      return { product, qty, ivaLine, totalLine };
    });
    const discount = Number(body.discount || 0);
    const total = Math.max(0, subtotal + ivaTotal - discount);
    if (body.pay_method === 'Efectivo' && Number(body.cash_received || 0) < total) throw new Error('El monto recibido no alcanza');

    const next = db.prepare('SELECT seq + 1 AS n FROM sqlite_sequence WHERE name=\'sales\'').get()?.n || 1;
    const invoice = invoiceNumber(next);
    const saleInfo = db.prepare(`INSERT INTO sales (invoice_no,user_id,client_id,cash_session_id,invoice_type,subtotal,iva_total,discount,total,pay_method,cash_received,change_amount,mixed_amount,observation) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
      .run(invoice, req.user.id, client.id, session.id, body.invoice_type || 'Factura', subtotal, ivaTotal, discount, total, body.pay_method || 'Efectivo', Number(body.cash_received || 0), Math.max(0, Number(body.cash_received || 0) - total), Number(body.mixed_amount || 0), body.observation || '');

    const saleId = saleInfo.lastInsertRowid;
    const itemStmt = db.prepare('INSERT INTO sale_items (sale_id,product_id,code,name,qty,unit_price,iva,total) VALUES (?,?,?,?,?,?,?,?)');
    const stockStmt = db.prepare('UPDATE products SET stock=?, updated_at=CURRENT_TIMESTAMP WHERE id=?');
    const moveStmt = db.prepare('INSERT INTO inventory_moves (product_id,user_id,type,qty,previous_stock,new_stock,reason) VALUES (?,?,?,?,?,?,?)');
    for (const line of prepared) {
      itemStmt.run(saleId, line.product.id, line.product.code, line.product.name, line.qty, line.product.price, line.ivaLine, line.totalLine);
      const newStock = line.product.stock - line.qty;
      stockStmt.run(newStock, line.product.id);
      moveStmt.run(line.product.id, req.user.id, 'venta', line.qty, line.product.stock, newStock, `Venta ${invoice}`);
    }
    audit(req.user, 'CREAR_VENTA', `Venta ${invoice} total $${total.toFixed(2)}`);
    return saleId;
  });

  try {
    const id = tx();
    res.status(201).json(fullSale(id));
  } catch (e) {
    res.status(400).json({ message: e.message });
  }
});

function fullSale(id) {
  const sale = db.prepare(`SELECT s.*,u.name cashier,c.name client_name,c.doc client_doc,c.address client_address FROM sales s JOIN users u ON u.id=s.user_id JOIN clients c ON c.id=s.client_id WHERE s.id=?`).get(id);
  if (!sale) return null;
  sale.items = db.prepare('SELECT * FROM sale_items WHERE sale_id=?').all(id);
  return sale;
}
app.get('/api/sales', auth, allow('admin','cajero','supervisor'), (req, res) => {
  const from = req.query.from || '1900-01-01';
  const to = req.query.to || '2999-12-31';
  const onlyMine = req.user.role === 'cajero';
  const sql = `SELECT s.*,u.name cashier,c.name client_name,c.doc client_doc FROM sales s JOIN users u ON u.id=s.user_id JOIN clients c ON c.id=s.client_id WHERE date(s.created_at) BETWEEN date(?) AND date(?) ${onlyMine ? 'AND s.user_id=?' : ''} ORDER BY s.id DESC LIMIT 300`;
  const rows = onlyMine ? db.prepare(sql).all(from, to, req.user.id) : db.prepare(sql).all(from, to);
  res.json(rows);
});
app.get('/api/sales/:id', auth, allow('admin','cajero','supervisor'), (req, res) => {
  const sale = fullSale(req.params.id);
  if (!sale) return res.status(404).json({ message: 'Venta no encontrada' });
  if (req.user.role === 'cajero' && sale.user_id !== req.user.id) return res.status(403).json({ message: 'Solo puedes ver tus ventas' });
  res.json(sale);
});
app.post('/api/sales/:id/cancel', auth, allow('admin','supervisor'), (req, res) => {
  const sale = db.prepare('SELECT * FROM sales WHERE id=?').get(req.params.id);
  if (!sale) return res.status(404).json({ message: 'Venta no encontrada' });
  if (sale.status !== 'emitida') return res.status(400).json({ message: 'La venta ya no está emitida' });
  const tx = db.transaction(() => {
    const items = db.prepare('SELECT * FROM sale_items WHERE sale_id=?').all(sale.id);
    for (const i of items) {
      const p = db.prepare('SELECT * FROM products WHERE id=?').get(i.product_id);
      const newStock = p.stock + i.qty;
      db.prepare('UPDATE products SET stock=? WHERE id=?').run(newStock, p.id);
      db.prepare('INSERT INTO inventory_moves (product_id,user_id,type,qty,previous_stock,new_stock,reason) VALUES (?,?,?,?,?,?,?)').run(p.id, req.user.id, 'devolucion', i.qty, p.stock, newStock, `Anulación venta ${sale.invoice_no}`);
    }
    db.prepare("UPDATE sales SET status='anulada' WHERE id=?").run(sale.id);
    audit(req.user, 'ANULAR_VENTA', `Anuló venta ${sale.invoice_no}. Motivo: ${req.body.reason || 'Sin motivo'}`);
  });
  tx();
  res.json(fullSale(req.params.id));
});

app.post('/api/inventory/move', auth, allow('admin','bodeguero'), (req, res) => {
  const { product_id, type, qty, reason } = req.body;
  const product = db.prepare('SELECT * FROM products WHERE id=?').get(product_id);
  if (!product) return res.status(404).json({ message: 'Producto no encontrado' });
  const q = Number(qty || 0);
  let newStock = product.stock;
  if (type === 'entrada' || type === 'devolucion') newStock += q;
  else if (type === 'salida' || type === 'merma' || type === 'vencido') newStock -= q;
  else if (type === 'ajuste') newStock = q;
  if (newStock < 0) return res.status(400).json({ message: 'El stock no puede quedar negativo' });
  db.prepare('UPDATE products SET stock=?, updated_at=CURRENT_TIMESTAMP WHERE id=?').run(newStock, product_id);
  db.prepare('INSERT INTO inventory_moves (product_id,user_id,type,qty,previous_stock,new_stock,reason) VALUES (?,?,?,?,?,?,?)').run(product_id, req.user.id, type, q, product.stock, newStock, reason || 'Movimiento manual');
  audit(req.user, 'MOVIMIENTO_INVENTARIO', `${type} ${q} unidades de ${product.code}`);
  res.json(db.prepare('SELECT * FROM products WHERE id=?').get(product_id));
});
app.get('/api/inventory/moves', auth, allow('admin','bodeguero','supervisor'), (_, res) => res.json(db.prepare(`SELECT im.*,p.code,p.name product,u.name user FROM inventory_moves im JOIN products p ON p.id=im.product_id JOIN users u ON u.id=im.user_id ORDER BY im.id DESC LIMIT 300`).all()));

app.post('/api/purchases', auth, allow('admin','bodeguero'), (req, res) => {
  const { supplier, items } = req.body;
  if (!supplier || !Array.isArray(items) || !items.length) return res.status(400).json({ message: 'Compra incompleta' });
  const tx = db.transaction(() => {
    const total = items.reduce((a, i) => a + Number(i.qty || 0) * Number(i.cost || 0), 0);
    const info = db.prepare('INSERT INTO purchases (supplier,user_id,total) VALUES (?,?,?)').run(supplier, req.user.id, total);
    for (const i of items) {
      const p = db.prepare('SELECT * FROM products WHERE id=?').get(i.product_id);
      if (!p) throw new Error('Producto no encontrado');
      const qty = Number(i.qty || 0);
      const cost = Number(i.cost || p.cost);
      db.prepare('INSERT INTO purchase_items (purchase_id,product_id,qty,cost,total) VALUES (?,?,?,?,?)').run(info.lastInsertRowid, p.id, qty, cost, qty * cost);
      db.prepare('UPDATE products SET stock=stock+?, cost=?, updated_at=CURRENT_TIMESTAMP WHERE id=?').run(qty, cost, p.id);
      db.prepare('INSERT INTO inventory_moves (product_id,user_id,type,qty,previous_stock,new_stock,reason) VALUES (?,?,?,?,?,?,?)').run(p.id, req.user.id, 'compra', qty, p.stock, p.stock + qty, `Compra a ${supplier}`);
    }
    audit(req.user, 'REGISTRAR_COMPRA', `Compra a ${supplier} por $${total.toFixed(2)}`);
    return info.lastInsertRowid;
  });
  try { res.status(201).json(db.prepare('SELECT * FROM purchases WHERE id=?').get(tx())); } catch (e) { res.status(400).json({ message: e.message }); }
});
app.get('/api/purchases', auth, allow('admin','bodeguero'), (_, res) => res.json(db.prepare(`SELECT p.*,u.name user FROM purchases p JOIN users u ON u.id=p.user_id ORDER BY p.id DESC LIMIT 200`).all()));

app.get('/api/reports/summary', auth, allow('admin','supervisor'), (req, res) => {
  const from = req.query.from || new Date().toISOString().slice(0,10);
  const to = req.query.to || from;
  const sales = db.prepare("SELECT COUNT(*) count, COALESCE(SUM(total),0) total FROM sales WHERE status='emitida' AND date(created_at) BETWEEN date(?) AND date(?)").get(from, to);
  const lowStock = db.prepare('SELECT COUNT(*) count FROM products WHERE active=1 AND stock <= min_stock').get();
  const valued = db.prepare('SELECT COALESCE(SUM(stock*cost),0) cost_value, COALESCE(SUM(stock*price),0) sale_value FROM products WHERE active=1').get();
  const top = db.prepare(`SELECT si.code,si.name,SUM(si.qty) qty,SUM(si.total) total FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE s.status='emitida' AND date(s.created_at) BETWEEN date(?) AND date(?) GROUP BY si.product_id ORDER BY qty DESC LIMIT 10`).all(from, to);
  res.json({ from, to, sales, lowStock: lowStock.count, inventoryValue: valued, topProducts: top });
});
app.get('/api/audit', auth, allow('admin','supervisor','bodeguero'), (_, res) => res.json(db.prepare('SELECT * FROM audit_log ORDER BY id DESC LIMIT 500').all()));

app.listen(PORT, () => console.log(`VentaPro API funcionando en http://localhost:${PORT}`));
