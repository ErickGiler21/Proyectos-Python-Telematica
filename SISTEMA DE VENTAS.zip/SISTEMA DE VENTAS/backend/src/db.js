import Database from 'better-sqlite3';
import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';

const DB_FILE = process.env.DB_FILE || './data/ventapro.sqlite';
fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });
export const db = new Database(DB_FILE);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

const IVA = 0.15;
const brands = ['Favorita','Supermaxi','Real','Dulcinea','Andina','Pacífico','Costeñito','La Fabril','Nestlé','Coca Cola','Toni','Pronaca','Maggi','Colgate','Familia','Dove','Deja','Tide','Lays','Natura'];
const cats = ['Abarrotes','Bebidas','Lácteos','Limpieza','Cuidado personal','Snacks','Carnes','Panadería','Ferretería básica','Mascotas'];
const names = ['Arroz','Aceite','Azúcar','Sal','Fideo','Atún','Sardina','Galletas','Café','Chocolate','Leche','Yogurt','Queso','Mantequilla','Agua','Cola','Jugo','Detergente','Cloro','Jabón','Papel higiénico','Shampoo','Desodorante','Papas','Harina','Avena','Huevos','Pollo','Pan','Cinta aislante','Foco LED','Clavos','Tornillos','Escoba','Fundas basura','Comida perro'];

export function initDb() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS company (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      ruc TEXT NOT NULL,
      name TEXT NOT NULL,
      trade_name TEXT NOT NULL,
      address TEXT,
      phone TEXT,
      email TEXT,
      iva REAL NOT NULL DEFAULT 0.15,
      logo TEXT,
      updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      username TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL CHECK(role IN ('admin','cajero','bodeguero','supervisor')),
      active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS clients (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      doc TEXT NOT NULL UNIQUE,
      type TEXT DEFAULT 'Cliente',
      name TEXT NOT NULL,
      phone TEXT,
      email TEXT,
      address TEXT,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT NOT NULL UNIQUE,
      barcode TEXT UNIQUE,
      name TEXT NOT NULL,
      brand TEXT,
      category TEXT,
      cost REAL NOT NULL DEFAULT 0,
      price REAL NOT NULL DEFAULT 0,
      iva REAL NOT NULL DEFAULT 0.15,
      stock INTEGER NOT NULL DEFAULT 0,
      min_stock INTEGER NOT NULL DEFAULT 5,
      active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS cash_sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      opening_amount REAL NOT NULL DEFAULT 0,
      closing_amount REAL,
      expected_amount REAL,
      difference REAL,
      status TEXT NOT NULL DEFAULT 'abierta' CHECK(status IN ('abierta','cerrada')),
      opened_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      closed_at TEXT,
      FOREIGN KEY(user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS sales (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      invoice_no TEXT NOT NULL UNIQUE,
      user_id INTEGER NOT NULL,
      client_id INTEGER NOT NULL,
      cash_session_id INTEGER,
      invoice_type TEXT NOT NULL DEFAULT 'Factura',
      subtotal REAL NOT NULL,
      iva_total REAL NOT NULL,
      discount REAL NOT NULL DEFAULT 0,
      total REAL NOT NULL,
      pay_method TEXT NOT NULL,
      cash_received REAL DEFAULT 0,
      change_amount REAL DEFAULT 0,
      mixed_amount REAL DEFAULT 0,
      observation TEXT,
      status TEXT NOT NULL DEFAULT 'emitida' CHECK(status IN ('emitida','anulada','devuelta')),
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(user_id) REFERENCES users(id),
      FOREIGN KEY(client_id) REFERENCES clients(id),
      FOREIGN KEY(cash_session_id) REFERENCES cash_sessions(id)
    );

    CREATE TABLE IF NOT EXISTS sale_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sale_id INTEGER NOT NULL,
      product_id INTEGER NOT NULL,
      code TEXT NOT NULL,
      name TEXT NOT NULL,
      qty INTEGER NOT NULL,
      unit_price REAL NOT NULL,
      iva REAL NOT NULL,
      total REAL NOT NULL,
      FOREIGN KEY(sale_id) REFERENCES sales(id),
      FOREIGN KEY(product_id) REFERENCES products(id)
    );

    CREATE TABLE IF NOT EXISTS inventory_moves (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      type TEXT NOT NULL CHECK(type IN ('entrada','salida','ajuste','devolucion','merma','vencido','venta','compra')),
      qty INTEGER NOT NULL,
      previous_stock INTEGER NOT NULL,
      new_stock INTEGER NOT NULL,
      reason TEXT,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(product_id) REFERENCES products(id),
      FOREIGN KEY(user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS purchases (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      supplier TEXT NOT NULL,
      user_id INTEGER NOT NULL,
      total REAL NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS purchase_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      purchase_id INTEGER NOT NULL,
      product_id INTEGER NOT NULL,
      qty INTEGER NOT NULL,
      cost REAL NOT NULL,
      total REAL NOT NULL,
      FOREIGN KEY(purchase_id) REFERENCES purchases(id),
      FOREIGN KEY(product_id) REFERENCES products(id)
    );

    CREATE TABLE IF NOT EXISTS audit_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      username TEXT,
      role TEXT,
      action TEXT NOT NULL,
      detail TEXT,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
  `);

  const hasCompany = db.prepare('SELECT COUNT(*) AS total FROM company').get().total;
  if (!hasCompany) {
    db.prepare(`INSERT INTO company (id,ruc,name,trade_name,address,phone,email,iva,logo) VALUES (1,?,?,?,?,?,?,?,?)`)
      .run('0999999999001','VentaPro Minimarket S.A.','VentaPro','Av. Principal y Calle Comercial','0999999999','ventas@ventapro.com',IVA,'');
  }

  const hasUsers = db.prepare('SELECT COUNT(*) AS total FROM users').get().total;
  if (!hasUsers) {
    const ins = db.prepare('INSERT INTO users (name,username,password_hash,role,active) VALUES (?,?,?,?,1)');
    const users = [
      ['Administrador','admin','admin1234','admin'],
      ['Cajero Principal','cajero','cajero1234','cajero'],
      ['Bodeguero','bodega','bodega1234','bodeguero'],
      ['Supervisor','supervisor','super1234','supervisor']
    ];
    users.forEach(u => ins.run(u[0], u[1], bcrypt.hashSync(u[2], 10), u[3]));
  }

  const cf = db.prepare('SELECT COUNT(*) AS total FROM clients WHERE doc=?').get('9999999999999').total;
  if (!cf) db.prepare('INSERT INTO clients (doc,type,name,phone,email,address) VALUES (?,?,?,?,?,?)').run('9999999999999','Consumidor Final','Consumidor Final','','','S/N');

  const hasProducts = db.prepare('SELECT COUNT(*) AS total FROM products').get().total;
  if (!hasProducts) seedProducts(1250);
}

export function seedProducts(amount = 1250) {
  const insert = db.prepare(`INSERT OR IGNORE INTO products (code,barcode,name,brand,category,cost,price,iva,stock,min_stock,active) VALUES (?,?,?,?,?,?,?,?,?,?,1)`);
  const tx = db.transaction(() => {
    for (let i = 1; i <= amount; i++) {
      const brand = brands[i % brands.length];
      const category = cats[i % cats.length];
      const n = names[i % names.length];
      const base = +(0.55 + (i % 90) * .22 + (i % 5) * .31).toFixed(2);
      insert.run(
        'P' + String(i).padStart(5, '0'),
        '786' + String(100000000 + i),
        `${n} ${['250 g','500 g','1 kg','2 L','pack x12','galón','unidad'][i % 7]}`,
        brand,
        category,
        +(base * .68).toFixed(2),
        base,
        IVA,
        20 + (i % 160),
        18 + (i % 8)
      );
    }
  });
  tx();
}

export function audit(user, action, detail = '') {
  db.prepare('INSERT INTO audit_log (user_id,username,role,action,detail) VALUES (?,?,?,?,?)')
    .run(user?.id || null, user?.username || 'sistema', user?.role || 'sistema', action, detail);
}

export function invoiceNumber(id) {
  return `001-001-${String(id).padStart(9, '0')}`;
}
