import fs from 'fs';
const file = process.env.DB_FILE || './data/ventapro.sqlite';
for (const f of [file, file+'-wal', file+'-shm']) if (fs.existsSync(f)) fs.unlinkSync(f);
console.log('Base de datos eliminada. Ejecuta npm run dev para crearla nuevamente.');
