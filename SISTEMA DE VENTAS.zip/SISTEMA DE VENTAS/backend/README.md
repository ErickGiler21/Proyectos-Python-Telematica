# VentaPro Backend Real Local

Backend real con API REST y base de datos SQLite.

## Ejecutar

```bash
cd backend
npm install
copy .env.example .env
npm run dev
```

La API queda en:

```text
http://localhost:8000
```

Prueba rápida:

```text
http://localhost:8000/api/health
```

## Usuarios iniciales

```text
admin / admin1234
cajero / cajero1234
bodega / bodega1234
supervisor / super1234
```

## Productos iniciales

Se crean 1250 productos demo automáticamente.

## Endpoints principales

- POST /api/auth/login
- GET /api/products
- POST /api/products
- GET /api/clients
- POST /api/clients
- POST /api/cash/open
- POST /api/sales
- POST /api/cash/close
- GET /api/sales
- GET /api/reports/summary
- GET /api/audit

## Nota

Este backend ya guarda datos en archivo SQLite real: `backend/data/ventapro.sqlite`.
Para producción se recomienda migrar a PostgreSQL y desplegar en VPS/Render/Railway.
